import ollama

prompt = (
    "Question: There are 8 books on a shelf. Tom removes 3 books and Sarah removes 2 more. How many books remain?\n"
    "Let's think step by step."
)
response = ollama.generate(model="llama3", prompt=prompt)
print(response['response'])