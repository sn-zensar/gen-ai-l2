import ollama

question = input("Ask a question about environmental science: ")
prompt = f"You are an expert in environmental science.\nUser: {question}\nAnswer:"

response = ollama.generate(model="llama3", prompt=prompt)
print(response['response'])