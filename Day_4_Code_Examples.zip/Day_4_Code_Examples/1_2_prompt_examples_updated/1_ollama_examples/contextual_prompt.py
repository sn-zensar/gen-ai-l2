import ollama

messages = [
    {"role": "system", "content": "You are a friendly chatbot."},
    {"role": "user", "content": "What is a healthy breakfast?"},
    {"role": "assistant", "content": "A healthy breakfast might include oatmeal, fruits, and yogurt."},
    {"role": "user", "content": "Can you suggest a quick recipe?"}
]

response = ollama.chat(model="llama3", messages=messages)
print(response['message'])