import ollama

prompt = "Write a short email requesting feedback on a recent meeting."
response = ollama.generate(model="llama3", prompt=prompt)
print(response['response'])