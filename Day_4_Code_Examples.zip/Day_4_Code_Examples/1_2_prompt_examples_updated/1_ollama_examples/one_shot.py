import ollama

prompt = (
    "Paraphrase the given sentence.\n"
    "Example:\n"
    "Original: The sky was clear and blue.\n"
    "Paraphrased: The blue sky was cloudless.\n"
    "Original: She completed the project ahead of schedule."
)
response = ollama.generate(model="llama3", prompt=prompt)
print(response['response'])