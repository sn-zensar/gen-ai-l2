import ollama

messages = [
    {"role": "system", "content": "You are a travel expert."},
    {"role": "user", "content": "I am travelling to Pune this weekend, Suggest 5 popular places to visit."}
]

# If Ollama library supports chat, use:
response = ollama.chat(model="llama3", messages=messages)
print(response['message'])