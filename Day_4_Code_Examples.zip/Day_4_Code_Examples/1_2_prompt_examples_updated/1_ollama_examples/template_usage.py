import ollama

text_to_summarize = input("Enter text to summarize: ")
prompt = f"Summarize the following text in two sentences:\n{text_to_summarize}"
response = ollama.generate(model="llama3", prompt=prompt)
print(response['response'])
