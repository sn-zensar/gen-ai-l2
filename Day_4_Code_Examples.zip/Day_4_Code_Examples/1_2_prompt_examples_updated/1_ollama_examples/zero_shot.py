import ollama

prompt = (
    "Summarize the main points of the following article in one line & 10 words: "
    "Artificial Intelligence is revolutionizing healthcare by enabling faster diagnostics, improving patient care, and reducing costs."
)
response = ollama.generate(model="llama3", prompt=prompt)
print(response['response'])