from langchain_community.llms import Ollama

llm = Ollama(model="llama3")
prompt = (
    "Question: There are 8 books on a shelf. Tom removes 3 books and Sarah removes 2 more. How many books remain?\n"
    "Let's think step by step."
)
response = llm.invoke(prompt)
print(response)