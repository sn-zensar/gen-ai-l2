from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.prompts import ChatPromptTemplate
from langchain_ollama import ChatOllama
 
# Initialize Ollama model (make sure it's running locally)
llm = ChatOllama(model="llama3", temperature=0)
 
print("Welcome! You can ask questions on any topic.")
print("Type 'change topic' to switch topics or 'exit' to quit.\n")
 
# Master loop for multiple topics
run = True
while run:
    topic = input("Enter the topic you'd like to ask about: ")
    if topic.lower() in ['exit', 'quit']:
        print("Goodbye!")
        break
 
    # Inner loop for multiple questions under the same topic
    while True:
        question = input("\nAsk your question (or type 'change topic' or 'exit'): ").strip()
        if question.lower() in ['exit', 'quit']:
            print("Goodbye!")
            run = False
            break
        elif question.lower() == 'change topic':
            break
 
        # Define chat prompt
        chat_template = ChatPromptTemplate.from_messages([
            ("system", "You are a helpful assistant that answers questions about {topic}."),
            ("human", "{question}")
        ])
 
        # Format messages and send
        formatted_chat_prompt = chat_template.format_messages(topic=topic, question=question)
        response = llm.invoke(formatted_chat_prompt)
 
        print("\nAnswer:", response.content)