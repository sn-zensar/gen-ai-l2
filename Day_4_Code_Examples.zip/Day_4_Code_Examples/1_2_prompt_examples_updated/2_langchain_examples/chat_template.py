from langchain.prompts import ChatPromptTemplate
from langchain_community.llms import Ollama

template = (
    "You are an expert  data engineer in - pyspark and databricks .\n"
    "User: {question}\n"
    "Answer:"
)
chat_prompt = ChatPromptTemplate.from_template(template)

user_question = input("Ask a question about pyspark and databricks: ")
filled_prompt = chat_prompt.format(question=user_question)

llm = Ollama(model="llama3")
response = llm.invoke(filled_prompt)
print(response)