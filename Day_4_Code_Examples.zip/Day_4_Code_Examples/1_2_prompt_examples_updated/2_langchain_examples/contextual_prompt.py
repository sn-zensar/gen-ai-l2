from langchain_community.llms import Ollama

messages = [
    {"role": "system", "content": "You are a friendly chatbot."},
    {"role": "user", "content": "What is a healthy breakfast?"},
    {"role": "assistant", "content": "A healthy breakfast might include oatmeal, fruits, and yogurt."},
    {"role": "user", "content": "Can you suggest a quick recipe?"}
]

llm = Ollama(model="llama3")
response = llm.chat(messages=messages)
print(response)
8. Prompt Template Usage
Prompt Templates: Reusable, parameterized text patterns.
Example Task
Summarizing arbitrary text input.