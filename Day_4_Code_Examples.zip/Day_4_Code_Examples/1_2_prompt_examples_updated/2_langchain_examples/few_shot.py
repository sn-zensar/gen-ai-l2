from langchain_community.llms import Ollama

llm = Ollama(model="llama3")
prompt = (
    "Rephrase each sentence in a more formal tone.\n"
    "Example:\n"
    "Original: Can you send me the report?\n"
    "Formal: Could you please send me the report?\n"
    "Original: Let me know if you need help.\n"
    "Formal: Please inform me if you require any assistance.\n"
    "Original: Get in touch if you have questions."
)
response = llm.invoke(prompt)
print(response)
4. Instruction Prompting
Instruction Prompting: The model is given a clear, direct instruction.
Example Prompt
"Write a short email requesting feedback on a recent meeting."