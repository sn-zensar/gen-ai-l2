from langchain_community.llms import Ollama

llm = Ollama(model="llama3")
prompt = "Write a short email requesting feedback on a recent meeting."
response = llm.invoke(prompt)
print(response)
