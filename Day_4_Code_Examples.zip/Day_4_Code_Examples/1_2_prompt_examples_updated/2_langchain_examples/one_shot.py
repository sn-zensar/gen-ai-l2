from langchain_community.llms import Ollama

llm = Ollama(model="llama3")
prompt = (
    "Paraphrase the given sentence.\n"
    "Example:\n"
    "Original: The sky was clear and blue.\n"
    "Paraphrased: The blue sky was cloudless.\n"
    "Original: She completed the project ahead of schedule."
)
response = llm.invoke(prompt)
print(response)

