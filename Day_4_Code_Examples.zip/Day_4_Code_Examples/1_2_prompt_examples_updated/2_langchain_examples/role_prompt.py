from langchain_community.llms import Ollama

messages = [
    {"role": "system", "content": "You are a travel expert."},
    {"role": "user", "content": "Suggest three unique weekend getaway ideas for a family in California."}
]

llm = Ollama(model="llama3")
response = llm.chat(messages=messages)
print(response)
7. Contextual Prompting (Conversational Memory)
Contextual Prompting: Maintaining context over several turns.
Example Conversation
System: "You are a friendly chatbot."
User: "What is a healthy breakfast?"
Assistant: "A healthy breakfast might include oatmeal, fruits, and yogurt."
User: "Can you suggest a quick recipe?"