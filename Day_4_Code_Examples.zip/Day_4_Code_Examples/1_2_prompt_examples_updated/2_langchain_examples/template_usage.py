from langchain.prompts import PromptTemplate
from langchain_community.llms import Ollama

template = "Summarize the following text in two sentences:\n{text}"
prompt_template = PromptTemplate.from_template(template)

user_text = input("Enter text to summarize: ")
prompt = prompt_template.format(text=user_text)

llm = Ollama(model="llama3")
response = llm.invoke(prompt)
print(response)
9. Chat-style Prompt Templates
Dynamic user input in a chat context.
Example Task
Answering user questions about a topic.