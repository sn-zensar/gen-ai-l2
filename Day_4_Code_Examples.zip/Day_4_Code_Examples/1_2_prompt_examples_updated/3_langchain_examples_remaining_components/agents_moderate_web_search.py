from langchain_community.llms import Ollama
from langchain.agents import initialize_agent, Tool

def search_web(query):
    # Fake code: in real life, use an API like SerpAPI or DuckDuckGo
    return f"Search results for {query}..."

search_tool = Tool.from_function(func=search_web, name="Web Search", description="Useful for answering factual questions from the web.")

llm = Ollama(model="llama3")
agent = initialize_agent([search_tool], llm, agent="zero-shot-react-description", verbose=True)

response = agent.invoke("Summarize the latest news about climate change.")
print(response["output"])
