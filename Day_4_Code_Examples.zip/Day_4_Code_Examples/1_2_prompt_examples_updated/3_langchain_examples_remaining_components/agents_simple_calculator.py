from langchain_community.llms import Ollama
from langchain.agents import initialize_agent, Tool

def add(a, b):
    return str(float(a) + float(b))

add_tool = Tool.from_function(func=add, name="Calculator", description="Adds two numbers.")

llm = Ollama(model="llama3")
agent = initialize_agent([add_tool], llm, agent="zero-shot-react-description", verbose=True)

result = agent.invoke("What is 7 plus 15?")
print(result["output"])
