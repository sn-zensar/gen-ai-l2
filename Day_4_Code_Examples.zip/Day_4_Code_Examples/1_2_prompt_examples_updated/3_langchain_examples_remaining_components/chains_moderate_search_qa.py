from langchain_community.llms import Ollama
from langchain.prompts import PromptTemplate
from langchain.chains import SequentialChain

# Prompt for searching
search_prompt = PromptTemplate.from_template("Find the relevant information about '{question}':\n{document}")
# Prompt for QA
qa_prompt = PromptTemplate.from_template("Based on this info:\n{context}\nAnswer:\n{question}")

llm = Ollama(model="llama3")

# Step 1: Search step
search_chain = LLMChain(llm=llm, prompt=search_prompt, output_key="context")
# Step 2: QA step
qa_chain = LLMChain(llm=llm, prompt=qa_prompt)

# Chaining steps sequentially
overall_chain = SequentialChain(
    chains=[search_chain, qa_chain],
    input_variables=["question", "document"],
    output_variables=["text"],
    verbose=True
)

user_doc = "Spark can be scaled to large clusters. It can run SQL and ML workloads. It uses in-memory computation."
question = "How does Spark scale workloads?"

result = overall_chain.invoke({"question": question, "document": user_doc})
print(result["text"])
