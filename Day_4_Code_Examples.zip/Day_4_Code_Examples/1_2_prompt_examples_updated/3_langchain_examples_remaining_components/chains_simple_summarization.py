from langchain_community.llms import Ollama
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain

# 1. Define the summarization prompt
template = "Summarize the following text in two sentences:\n{text}"
prompt = PromptTemplate.from_template(template)

# 2. Language model setup
llm = Ollama(model="llama3")

# 3. Build chain
chain = LLMChain(llm=llm, prompt=prompt)

user_input = "A spark cluster allows big data computation by distributing work..."
result = chain.invoke({"text": user_input})
print(result["text"])
