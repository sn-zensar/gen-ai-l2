from langchain_community.llms import Ollama
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain

llm = Ollama(model="llama3")
memory = ConversationBufferMemory()

conversation = ConversationalRetrievalChain.from_llm(llm, retriever=None, memory=memory)

user1 = "What is the capital of Italy?"
response1 = conversation.invoke({"question": user1})
print(response1["answer"])

user2 = "And what about France?"
response2 = conversation.invoke({"question": user2})
print(response2["answer"])
