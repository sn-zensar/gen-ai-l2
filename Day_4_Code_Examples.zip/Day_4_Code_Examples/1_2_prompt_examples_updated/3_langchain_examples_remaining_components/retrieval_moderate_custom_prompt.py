from langchain_community.llms import Ollama
from langchain.vectorstores import FAISS
from langchain.embeddings import OllamaEmbeddings
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

llm = Ollama(model="llama3")
embedding = OllamaEmbeddings(model="llama3")

# List of document dictionaries
docs = [{"text": f"Document {i} about Spark tuning and optimization."} for i in range(10)]

vectorstore = FAISS.from_documents(docs, embedding)
retriever = vectorstore.as_retriever()

custom_prompt = PromptTemplate.from_template(
    "Based on the following context:\n{context}\nAnswer the question: {question}"
)

qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    chain_type_kwargs={"prompt": custom_prompt}
)

question = "List key points on Spark optimization."
print(qa_chain.invoke(question)["result"])
