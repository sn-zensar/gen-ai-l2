from langchain_community.llms import Ollama
from langchain.vectorstores import FAISS
from langchain.embeddings import OllamaEmbeddings
from langchain.chains import RetrievalQA

llm = Ollama(model="llama3")
embedding = OllamaEmbeddings(model="llama3")

docs = [
    {"text": "The Eiffel Tower is in Paris."},
    {"text": "Python is a popular programming language."},
]

# Build index
vectorstore = FAISS.from_documents(docs, embedding)
retriever = vectorstore.as_retriever()

qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
print(qa_chain.invoke("Where is the Eiffel Tower?")["result"])
