from langchain_community.llms import Ollama
from langchain.agents import initialize_agent, Tool

def get_time():
    from datetime import datetime
    return datetime.now().strftime("%H:%M:%S")

def convert_temp(temp_c):
    return str(round((float(temp_c) * 9/5) + 32, 2)) + " F"

tools = [
    Tool.from_function(get_time, name="Current Time", description="Returns the current time."),
    Tool.from_function(convert_temp, name="Celsius to Fahrenheit", description="Converts Celsius to Fahrenheit.")
]

llm = Ollama(model="llama3")
agent = initialize_agent(tools, llm, agent="zero-shot-react-description", verbose=True)

print(agent.invoke("Convert 22 Celsius to Fahrenheit, and tell me the current time.")["output"])
