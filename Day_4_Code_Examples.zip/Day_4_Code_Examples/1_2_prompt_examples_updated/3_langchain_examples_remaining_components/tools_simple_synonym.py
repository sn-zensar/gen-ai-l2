from langchain.agents import Tool

def synonyms(word):
    # Fake function for illustration
    return {"quick": "fast, speedy", "happy": "joyful, glad"}.get(word, "No synonym found.")

synonym_tool = Tool.from_function(func=synonyms, name="Synonym Finder", description="Finds synonyms for an English word.")
print(synonym_tool.func("quick"))  # Output: fast, speedy
