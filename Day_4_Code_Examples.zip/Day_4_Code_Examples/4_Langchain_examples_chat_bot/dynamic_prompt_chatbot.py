# Import necessary modules
from langchain.prompts import PromptTemplate
from langchain_ollama import ChatOllama

# Define the prompt template
template = """
You are a helpful assistant that answers questions about {topic}.

Question: {question}
Answer:
"""

# Create prompt template object
prompt = PromptTemplate(
    input_variables=["topic", "question"],
    template=template,
)

# Initialize Ollama LLM
llm = ChatOllama(model="llama3", temperature=0)

# Infinite loop to allow multiple questions
while True:
    topic = input("Enter a topic (or type 'exit' to quit): ")
    if topic.lower() == "exit":
        print("Goodbye!")
        break

    question = input("Enter your question: ")

    # Format the prompt
    formatted_prompt = prompt.format(topic=topic, question=question)

    # Get response from Ollama
    response = llm.invoke(formatted_prompt)

    # Display the response
    print("\n🧠 Assistant:", response.content)
    print("-" * 50)
