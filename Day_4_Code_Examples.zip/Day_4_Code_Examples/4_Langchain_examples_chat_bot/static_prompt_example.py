# Import necessary modules
from langchain.prompts import PromptTemplate
from langchain_ollama import ChatOllama

# Define the prompt template
template = """
You are a helpful assistant that answers questions about {topic}.

Question: {question}
Answer:
"""

prompt = PromptTemplate(
    input_variables=["topic", "question"],
    template=template,
)

# Initialize the Ollama LLM (make sure 'ollama run llama3' is available)
llm = ChatOllama(model="llama3", temperature=0)

# Format the prompt with specific values
formatted_prompt = prompt.format(topic="Cricket", question="Who is Ravi Shastri? and What roles he worked in?")

# Run the prompt through the model
response = llm.invoke(formatted_prompt)

# Print the response content
print(response.content)
