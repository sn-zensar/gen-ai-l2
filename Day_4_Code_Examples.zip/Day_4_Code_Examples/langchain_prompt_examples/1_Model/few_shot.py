from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage, SystemMessage

llm = ChatOllama(model='llama3')

import ollama

prompt = '''Translate the following English words to Hindi:
English: mango
Hindi: आम
English: banana
Hindi: केला
English: apple
Hindi:'''

response = ollama.chat(
    model='llama3',
    messages=[
        {"role": "user", "content": prompt}
    ]
)

print(response['message']['content'])