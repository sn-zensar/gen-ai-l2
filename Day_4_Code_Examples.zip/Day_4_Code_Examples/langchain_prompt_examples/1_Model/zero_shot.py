from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage, SystemMessage

llm = ChatOllama(model='llama3')

import ollama

response = ollama.chat(
    model='llama3',
    messages=[
        {"role": "user", "content": "Translate 'apple' into Hindi."}
    ]
)

print(response['message']['content'])