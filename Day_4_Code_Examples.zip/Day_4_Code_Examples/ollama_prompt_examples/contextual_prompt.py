import ollama

messages = [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "What is machine learning?"},
    {"role": "assistant", "content": "Machine learning is a field of AI where computers learn from data to make decisions or predictions."},
    {"role": "user", "content": "Can you give me an example?"}
]

response = ollama.chat(
    model='llama3',
    messages=messages
)

print(response['message']['content'])