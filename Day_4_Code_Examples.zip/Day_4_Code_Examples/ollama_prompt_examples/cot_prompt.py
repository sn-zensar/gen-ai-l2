import ollama

prompt = '''Question: If there are 3 red balls and 2 green balls in a box, and you randomly pick one, what is the probability it is red?
Let's think step by step.'''

response = ollama.chat(
    model='llama3',
    messages=[
        {"role": "user", "content": prompt}
    ]
)

print(response['message']['content'])