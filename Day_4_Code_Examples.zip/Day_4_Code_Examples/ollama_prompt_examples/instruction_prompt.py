import ollama

prompt = "Summarize the following text in one sentence:\nText: 'Artificial Intelligence is a branch of computer science that focuses on creating systems capable of performing tasks that normally require human intelligence.'"

response = ollama.chat(
    model='llama3',
    messages=[
        {"role": "user", "content": prompt}
    ]
)

print(response['message']['content'])