from langchain_community.llms import Ollama

llm = Ollama(model="llama3")
prompt = (
    "Summarize the main points of the following article: "
    "Artificial Intelligence is revolutionizing healthcare by enabling faster diagnostics, improving patient care, and reducing costs."
)
response = llm.invoke(prompt)
print(response)
2. One-shot Prompting
One-shot: Provide a single example along with the new task.
Example Prompt
"Paraphrase the given sentence.
Example:
Original: The sky was clear and blue.
Paraphrased: The blue sky was cloudless.
Original: She completed the project ahead of schedule."