from langchain_community.llms import Ollama

llm = Ollama(model="llama3")
prompt = (
    "Paraphrase the given sentence.\n"
    "Example:\n"
    "Original: The sky was clear and blue.\n"
    "Paraphrased: The blue sky was cloudless.\n"
    "Original: She completed the project ahead of schedule."
)
response = llm.invoke(prompt)
print(response)
3. Few-shot Prompting
Few-shot: Multiple examples are provided to show the desired pattern.
Example Prompt
"Rephrase each sentence in a more formal tone.
Example:
Original: Can you send me the report?
Formal: Could you please send me the report?
Original: Let me know if you need help.
Formal: Please inform me if you require any assistance.
Original: Get in touch if you have questions."