from langchain_community.llms import Ollama

llm = Ollama(model="llama3")
prompt = "Write a short email requesting feedback on a recent meeting."
response = llm.invoke(prompt)
print(response)
5. Chain-of-Thought (CoT) Prompting
CoT: Ask the model to reason step-by-step.
Example Prompt
"Question: There are 8 books on a shelf. Tom removes 3 books and Sarah removes 2 more. How many books remain?
Let's think step by step."