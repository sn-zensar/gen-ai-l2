import ollama

messages = [
    {"role": "system", "content": "You are a travel expert."},
    {"role": "user", "content": "Suggest three unique weekend getaway ideas for a family in California."}
]

# If Ollama library supports chat, use:
response = ollama.chat(model="llama3", messages=messages)
print(response['message'])